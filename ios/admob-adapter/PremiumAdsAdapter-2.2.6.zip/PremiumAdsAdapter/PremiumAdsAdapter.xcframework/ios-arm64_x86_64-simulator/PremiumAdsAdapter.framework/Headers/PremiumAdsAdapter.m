//
//  PremiumAdsAdapter.m
//  Adapter
//
//  Created by Hai Le Xuan on 21/03/2023.
//  Copyright © 2023 Google. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PremiumAdsAdapter.h>

@implementation PremiumAdsAdapter

+ (void)onLog:(nonnull NSString *)log {
  NSLog(@"IronSourceAdapter: %@", log);
}
